z="
";Cz='33[3';Gz='══╗"';Dz='4;1m';Ez='╔═══';Bz=' "\0';Fz='════';Az='echo';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Gz" 
