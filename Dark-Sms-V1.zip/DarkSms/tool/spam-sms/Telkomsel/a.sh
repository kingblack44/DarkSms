z="
";Az='echo';Gz='══╗"';Bz=' "\0';Dz='4;1m';Cz='33[3';Ez='╔═══';Fz='════';
eval "$Az$z$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Gz" 
